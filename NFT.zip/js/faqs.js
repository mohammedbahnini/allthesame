$(document).ready(() => {

    $('.faq-list .faq-item').on('click', function (e) {
        $(this).toggleClass('active');
    });
});